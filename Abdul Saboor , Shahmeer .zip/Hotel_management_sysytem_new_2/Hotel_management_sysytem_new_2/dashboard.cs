﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_management_sysytem_new_2
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

       

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnbooking_Click(object sender, EventArgs e)
        {
            booking bookinginfo = new booking();
            bookinginfo.Show();
        }

        private void btnroom_Click(object sender, EventArgs e)
        {
            Room RoomInfo = new Room();
            RoomInfo.Show();
        }

        private void btnguest_Click(object sender, EventArgs e)
        {
            Guest GuestInfo = new Guest();
            GuestInfo.Show();
        }

        private void btnemployee_Click(object sender, EventArgs e)
        {
            Employee EmployeeInfo = new Employee();
            EmployeeInfo.Show();
        }

        private void btnbill_Click(object sender, EventArgs e)
        {
            Bill BillInfo = new Bill(); 
            BillInfo.Show();
        }
    }
}
