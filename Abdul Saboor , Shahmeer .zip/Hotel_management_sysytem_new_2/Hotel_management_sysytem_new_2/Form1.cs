﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_management_sysytem_new_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if(txtusername.Text == "dell7490" && txtpassword.Text == "7490")
            {
                labelerrror.Visible = false;
                dashboard ds = new dashboard();
                this.Hide();
                ds.Show();
            }
            else
            {
                ;labelerrror.Visible = true;
                txtpassword.Clear();
            }
        }

       
    }
}
