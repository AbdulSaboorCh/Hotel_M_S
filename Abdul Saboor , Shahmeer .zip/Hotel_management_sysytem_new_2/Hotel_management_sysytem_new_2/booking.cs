﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hotel_management_sysytem_new_2
{
    public partial class booking : Form
    {
        public booking()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("INSERT INTO dbo.[Table] VALUES (@id, @guestname, @room_no, @room_type, @hotel_code)", con);

            cnn.Parameters.AddWithValue("@id", int.Parse(gunaTextBox1.Text));
            cnn.Parameters.AddWithValue("@guestname", gunaTextBox2.Text);
            cnn.Parameters.AddWithValue("@room_no", int.Parse(gunaTextBox3.Text));
            cnn.Parameters.AddWithValue("@room_type", gunaTextBox4.Text);
            cnn.Parameters.AddWithValue("@hotel_code", gunaTextBox5.Text);

            cnn.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Saved Successfully", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
            SqlCommand cnn = new SqlCommand("SELECT * FROM dbo.[Table]", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            gunaDataGridView1.DataSource = table;
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
            SqlCommand cnn = new SqlCommand("SELECT * FROM dbo.[Table]", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            gunaDataGridView1.DataSource = table;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
            con.Open();

            SqlCommand cnn = new SqlCommand("Update Table Set guestname=@guestname, Room_No=@Room_No, room_type=@room_type, hotel_code=@hotel_code WHERE id=@id", con);

            cnn.Parameters.AddWithValue("@id", int.Parse(gunaTextBox1.Text));
            cnn.Parameters.AddWithValue("@guestname", gunaTextBox2.Text);
            cnn.Parameters.AddWithValue("@Room_No", int.Parse(gunaTextBox3.Text));
            cnn.Parameters.AddWithValue("@room_type", gunaTextBox4.Text);
            cnn.Parameters.AddWithValue("@hotel_code", gunaTextBox5.Text);

            cnn.ExecuteNonQuery();

            con.Close();
            MessageBox.Show("Updated Successfully", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
