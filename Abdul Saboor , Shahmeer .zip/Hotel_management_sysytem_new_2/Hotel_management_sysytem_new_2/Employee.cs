﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hotel_management_sysytem_new_2
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
                con.Open();

                SqlCommand cnn = new SqlCommand("INSERT INTO dbo.[EmployeeTable] VALUES (@id, @name, @Age)", con);

                cnn.Parameters.AddWithValue("@id", int.Parse(txtempid.Text));
                cnn.Parameters.AddWithValue("@name", txtempname.Text);
                cnn.Parameters.AddWithValue("@Age", int.Parse(txtempage.Text));
                

                cnn.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Saved Successfully", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
            SqlCommand cnn = new SqlCommand("SELECT * FROM dbo.[EmployeeTable]", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            gunaDataGridView1.DataSource = table;
        }

        private void btndisplay_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
            SqlCommand cnn = new SqlCommand("SELECT * FROM dbo.[EmployeeTable]", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            gunaDataGridView1.DataSource = table;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-8BL3MIG\SQLEXPRESS;Initial Catalog=hoteldbnew2;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("Update EmployeeTable set name=@name , Age=@age where Id=@Id", con);
            cnn.Parameters.AddWithValue("@id", int.Parse(txtempid.Text));
            cnn.Parameters.AddWithValue("@Name", txtempname.Text);
            cnn.Parameters.AddWithValue("@Age", int.Parse(txtempage.Text));
            

            cnn.ExecuteNonQuery();
            con.Close();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
