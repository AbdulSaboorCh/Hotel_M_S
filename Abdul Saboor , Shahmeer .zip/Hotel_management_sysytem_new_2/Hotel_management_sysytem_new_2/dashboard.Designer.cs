﻿namespace Hotel_management_sysytem_new_2
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.btnguest = new Guna.UI.WinForms.GunaButton();
            this.btnemployee = new Guna.UI.WinForms.GunaButton();
            this.btnbill = new Guna.UI.WinForms.GunaButton();
            this.btnroom = new Guna.UI.WinForms.GunaButton();
            this.btnbooking = new Guna.UI.WinForms.GunaButton();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.btnExit = new Guna.UI.WinForms.GunaImageButton();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gunaPanel2.SuspendLayout();
            this.gunaPanel1.SuspendLayout();
            this.gunaPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.gunaPanel2);
            this.panel1.Location = new System.Drawing.Point(3, 58);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1168, 536);
            this.panel1.TabIndex = 0;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gunaPanel2.Controls.Add(this.btnguest);
            this.gunaPanel2.Controls.Add(this.btnemployee);
            this.gunaPanel2.Controls.Add(this.btnbill);
            this.gunaPanel2.Controls.Add(this.btnroom);
            this.gunaPanel2.Controls.Add(this.btnbooking);
            this.gunaPanel2.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(200, 536);
            this.gunaPanel2.TabIndex = 0;
            // 
            // btnguest
            // 
            this.btnguest.AnimationHoverSpeed = 0.07F;
            this.btnguest.AnimationSpeed = 0.03F;
            this.btnguest.BackColor = System.Drawing.Color.Transparent;
            this.btnguest.BaseColor = System.Drawing.Color.CadetBlue;
            this.btnguest.BorderColor = System.Drawing.Color.Black;
            this.btnguest.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnguest.FocusedColor = System.Drawing.Color.Empty;
            this.btnguest.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnguest.ForeColor = System.Drawing.Color.White;
            this.btnguest.Image = null;
            this.btnguest.ImageSize = new System.Drawing.Size(20, 20);
            this.btnguest.Location = new System.Drawing.Point(16, 197);
            this.btnguest.Name = "btnguest";
            this.btnguest.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnguest.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnguest.OnHoverForeColor = System.Drawing.Color.White;
            this.btnguest.OnHoverImage = null;
            this.btnguest.OnPressedColor = System.Drawing.Color.Black;
            this.btnguest.Size = new System.Drawing.Size(160, 42);
            this.btnguest.TabIndex = 2;
            this.btnguest.Text = "Guest";
            this.btnguest.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnguest.Click += new System.EventHandler(this.btnguest_Click);
            // 
            // btnemployee
            // 
            this.btnemployee.AnimationHoverSpeed = 0.07F;
            this.btnemployee.AnimationSpeed = 0.03F;
            this.btnemployee.BackColor = System.Drawing.Color.Transparent;
            this.btnemployee.BaseColor = System.Drawing.Color.CadetBlue;
            this.btnemployee.BorderColor = System.Drawing.Color.Black;
            this.btnemployee.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnemployee.FocusedColor = System.Drawing.Color.Empty;
            this.btnemployee.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnemployee.ForeColor = System.Drawing.Color.White;
            this.btnemployee.Image = null;
            this.btnemployee.ImageSize = new System.Drawing.Size(20, 20);
            this.btnemployee.Location = new System.Drawing.Point(16, 255);
            this.btnemployee.Name = "btnemployee";
            this.btnemployee.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnemployee.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnemployee.OnHoverForeColor = System.Drawing.Color.White;
            this.btnemployee.OnHoverImage = null;
            this.btnemployee.OnPressedColor = System.Drawing.Color.Black;
            this.btnemployee.Size = new System.Drawing.Size(160, 42);
            this.btnemployee.TabIndex = 3;
            this.btnemployee.Text = "Employee";
            this.btnemployee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnemployee.Click += new System.EventHandler(this.btnemployee_Click);
            // 
            // btnbill
            // 
            this.btnbill.AnimationHoverSpeed = 0.07F;
            this.btnbill.AnimationSpeed = 0.03F;
            this.btnbill.BackColor = System.Drawing.Color.Transparent;
            this.btnbill.BaseColor = System.Drawing.Color.CadetBlue;
            this.btnbill.BorderColor = System.Drawing.Color.Black;
            this.btnbill.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnbill.FocusedColor = System.Drawing.Color.Empty;
            this.btnbill.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnbill.ForeColor = System.Drawing.Color.White;
            this.btnbill.Image = null;
            this.btnbill.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.btnbill.ImageSize = new System.Drawing.Size(20, 20);
            this.btnbill.Location = new System.Drawing.Point(16, 314);
            this.btnbill.Name = "btnbill";
            this.btnbill.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnbill.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnbill.OnHoverForeColor = System.Drawing.Color.White;
            this.btnbill.OnHoverImage = null;
            this.btnbill.OnPressedColor = System.Drawing.Color.Black;
            this.btnbill.Size = new System.Drawing.Size(160, 42);
            this.btnbill.TabIndex = 4;
            this.btnbill.Text = "Bill";
            this.btnbill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnbill.Click += new System.EventHandler(this.btnbill_Click);
            // 
            // btnroom
            // 
            this.btnroom.AnimationHoverSpeed = 0.07F;
            this.btnroom.AnimationSpeed = 0.03F;
            this.btnroom.BackColor = System.Drawing.Color.Transparent;
            this.btnroom.BaseColor = System.Drawing.Color.CadetBlue;
            this.btnroom.BorderColor = System.Drawing.Color.Black;
            this.btnroom.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnroom.FocusedColor = System.Drawing.Color.Empty;
            this.btnroom.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnroom.ForeColor = System.Drawing.Color.White;
            this.btnroom.Image = null;
            this.btnroom.ImageSize = new System.Drawing.Size(20, 20);
            this.btnroom.Location = new System.Drawing.Point(16, 135);
            this.btnroom.Name = "btnroom";
            this.btnroom.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnroom.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnroom.OnHoverForeColor = System.Drawing.Color.White;
            this.btnroom.OnHoverImage = null;
            this.btnroom.OnPressedColor = System.Drawing.Color.Black;
            this.btnroom.Size = new System.Drawing.Size(160, 42);
            this.btnroom.TabIndex = 2;
            this.btnroom.Text = "Room";
            this.btnroom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnroom.Click += new System.EventHandler(this.btnroom_Click);
            // 
            // btnbooking
            // 
            this.btnbooking.AnimationHoverSpeed = 0.07F;
            this.btnbooking.AnimationSpeed = 0.03F;
            this.btnbooking.BackColor = System.Drawing.Color.Transparent;
            this.btnbooking.BaseColor = System.Drawing.Color.CadetBlue;
            this.btnbooking.BorderColor = System.Drawing.Color.Black;
            this.btnbooking.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnbooking.FocusedColor = System.Drawing.Color.Empty;
            this.btnbooking.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbooking.ForeColor = System.Drawing.Color.White;
            this.btnbooking.Image = null;
            this.btnbooking.ImageSize = new System.Drawing.Size(20, 20);
            this.btnbooking.Location = new System.Drawing.Point(16, 76);
            this.btnbooking.Name = "btnbooking";
            this.btnbooking.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnbooking.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnbooking.OnHoverForeColor = System.Drawing.Color.White;
            this.btnbooking.OnHoverImage = null;
            this.btnbooking.OnPressedColor = System.Drawing.Color.Black;
            this.btnbooking.Size = new System.Drawing.Size(160, 42);
            this.btnbooking.TabIndex = 1;
            this.btnbooking.Text = "Booking";
            this.btnbooking.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnbooking.Click += new System.EventHandler(this.btnbooking_Click);
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gunaPanel1.Controls.Add(this.btnExit);
            this.gunaPanel1.Controls.Add(this.gunaLabel1);
            this.gunaPanel1.Location = new System.Drawing.Point(3, 1);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(1168, 60);
            this.gunaPanel1.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageSize = new System.Drawing.Size(64, 64);
            this.btnExit.Location = new System.Drawing.Point(1113, 6);
            this.btnExit.Name = "btnExit";
            this.btnExit.OnHoverImage = null;
            this.btnExit.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.btnExit.Size = new System.Drawing.Size(52, 51);
            this.btnExit.TabIndex = 1;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Franklin Gothic Medium", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(9, 8);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(414, 37);
            this.gunaLabel1.TabIndex = 0;
            this.gunaLabel1.Text = "Hotel Management System";
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.gunaPanel3.Controls.Add(this.label1);
            this.gunaPanel3.Location = new System.Drawing.Point(3, 58);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(200, 70);
            this.gunaPanel3.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mehran Hotel";
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1173, 594);
            this.Controls.Add(this.gunaPanel3);
            this.Controls.Add(this.gunaPanel1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "dashboard";
            this.Text = "dashboard";
            this.panel1.ResumeLayout(false);
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            this.gunaPanel3.ResumeLayout(false);
            this.gunaPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaButton btnbooking;
        private Guna.UI.WinForms.GunaButton btnroom;
        private Guna.UI.WinForms.GunaButton btnguest;
        private Guna.UI.WinForms.GunaButton btnemployee;
        private Guna.UI.WinForms.GunaButton btnbill;
        private Guna.UI.WinForms.GunaImageButton btnExit;
    }
}