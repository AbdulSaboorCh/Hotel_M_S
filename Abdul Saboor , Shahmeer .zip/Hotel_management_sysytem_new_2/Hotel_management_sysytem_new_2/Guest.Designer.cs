﻿namespace Hotel_management_sysytem_new_2
{
    partial class Guest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Guest));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.btnexit = new Guna.UI.WinForms.GunaImageButton();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaGroupBox1 = new Guna.UI.WinForms.GunaGroupBox();
            this.btndisplay = new Guna.UI.WinForms.GunaButton();
            this.btnupdate = new Guna.UI.WinForms.GunaButton();
            this.btnadd = new Guna.UI.WinForms.GunaButton();
            this.btnsave = new Guna.UI.WinForms.GunaButton();
            this.txtguestaddress = new Guna.UI.WinForms.GunaTextBox();
            this.txtguestphone = new Guna.UI.WinForms.GunaTextBox();
            this.txtguestage = new Guna.UI.WinForms.GunaTextBox();
            this.txtguestname = new Guna.UI.WinForms.GunaTextBox();
            this.txtguestid = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.guestrno = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaDataGridView1 = new Guna.UI.WinForms.GunaDataGridView();
            this.gunaPanel1.SuspendLayout();
            this.gunaGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaDataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.gunaPanel1.Controls.Add(this.btnexit);
            this.gunaPanel1.Controls.Add(this.gunaLabel1);
            this.gunaPanel1.Location = new System.Drawing.Point(3, 1);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(1168, 75);
            this.gunaPanel1.TabIndex = 2;
            // 
            // btnexit
            // 
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnexit.Image = ((System.Drawing.Image)(resources.GetObject("btnexit.Image")));
            this.btnexit.ImageSize = new System.Drawing.Size(64, 64);
            this.btnexit.Location = new System.Drawing.Point(1108, 6);
            this.btnexit.Name = "btnexit";
            this.btnexit.OnHoverImage = null;
            this.btnexit.OnHoverImageOffset = new System.Drawing.Point(0, 0);
            this.btnexit.Size = new System.Drawing.Size(47, 42);
            this.btnexit.TabIndex = 2;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Franklin Gothic Medium", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(3, 0);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(125, 47);
            this.gunaLabel1.TabIndex = 1;
            this.gunaLabel1.Text = "Guest";
            // 
            // gunaGroupBox1
            // 
            this.gunaGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.gunaGroupBox1.BaseColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.gunaGroupBox1.BorderColor = System.Drawing.Color.Gainsboro;
            this.gunaGroupBox1.Controls.Add(this.btndisplay);
            this.gunaGroupBox1.Controls.Add(this.btnupdate);
            this.gunaGroupBox1.Controls.Add(this.btnadd);
            this.gunaGroupBox1.Controls.Add(this.btnsave);
            this.gunaGroupBox1.Controls.Add(this.txtguestaddress);
            this.gunaGroupBox1.Controls.Add(this.txtguestphone);
            this.gunaGroupBox1.Controls.Add(this.txtguestage);
            this.gunaGroupBox1.Controls.Add(this.txtguestname);
            this.gunaGroupBox1.Controls.Add(this.txtguestid);
            this.gunaGroupBox1.Controls.Add(this.gunaLabel8);
            this.gunaGroupBox1.Controls.Add(this.gunaLabel7);
            this.gunaGroupBox1.Controls.Add(this.guestrno);
            this.gunaGroupBox1.Controls.Add(this.gunaLabel5);
            this.gunaGroupBox1.Controls.Add(this.gunaLabel4);
            this.gunaGroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaGroupBox1.LineColor = System.Drawing.Color.Transparent;
            this.gunaGroupBox1.Location = new System.Drawing.Point(3, 75);
            this.gunaGroupBox1.Name = "gunaGroupBox1";
            this.gunaGroupBox1.Size = new System.Drawing.Size(578, 479);
            this.gunaGroupBox1.TabIndex = 3;
            this.gunaGroupBox1.Text = "Guest";
            this.gunaGroupBox1.TextLocation = new System.Drawing.Point(10, 8);
            // 
            // btndisplay
            // 
            this.btndisplay.AnimationHoverSpeed = 0.07F;
            this.btndisplay.AnimationSpeed = 0.03F;
            this.btndisplay.BackColor = System.Drawing.Color.Transparent;
            this.btndisplay.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btndisplay.BorderColor = System.Drawing.Color.Black;
            this.btndisplay.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btndisplay.FocusedColor = System.Drawing.Color.Empty;
            this.btndisplay.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndisplay.ForeColor = System.Drawing.Color.White;
            this.btndisplay.Image = null;
            this.btndisplay.ImageSize = new System.Drawing.Size(20, 20);
            this.btndisplay.Location = new System.Drawing.Point(448, 331);
            this.btndisplay.Name = "btndisplay";
            this.btndisplay.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btndisplay.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btndisplay.OnHoverForeColor = System.Drawing.Color.White;
            this.btndisplay.OnHoverImage = null;
            this.btndisplay.OnPressedColor = System.Drawing.Color.Black;
            this.btndisplay.Radius = 8;
            this.btndisplay.Size = new System.Drawing.Size(118, 42);
            this.btndisplay.TabIndex = 13;
            this.btndisplay.Text = "Display";
            this.btndisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btndisplay.Click += new System.EventHandler(this.btndisplay_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.AnimationHoverSpeed = 0.07F;
            this.btnupdate.AnimationSpeed = 0.03F;
            this.btnupdate.BackColor = System.Drawing.Color.Transparent;
            this.btnupdate.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btnupdate.BorderColor = System.Drawing.Color.Black;
            this.btnupdate.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnupdate.FocusedColor = System.Drawing.Color.Empty;
            this.btnupdate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.White;
            this.btnupdate.Image = null;
            this.btnupdate.ImageSize = new System.Drawing.Size(20, 20);
            this.btnupdate.Location = new System.Drawing.Point(309, 331);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnupdate.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnupdate.OnHoverForeColor = System.Drawing.Color.White;
            this.btnupdate.OnHoverImage = null;
            this.btnupdate.OnPressedColor = System.Drawing.Color.Black;
            this.btnupdate.Radius = 8;
            this.btnupdate.Size = new System.Drawing.Size(118, 42);
            this.btnupdate.TabIndex = 12;
            this.btnupdate.Text = "Update";
            this.btnupdate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnadd
            // 
            this.btnadd.AnimationHoverSpeed = 0.07F;
            this.btnadd.AnimationSpeed = 0.03F;
            this.btnadd.BackColor = System.Drawing.Color.Transparent;
            this.btnadd.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btnadd.BorderColor = System.Drawing.Color.Black;
            this.btnadd.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnadd.FocusedColor = System.Drawing.Color.Empty;
            this.btnadd.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.ForeColor = System.Drawing.Color.White;
            this.btnadd.Image = null;
            this.btnadd.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnadd.ImageSize = new System.Drawing.Size(20, 20);
            this.btnadd.Location = new System.Drawing.Point(166, 331);
            this.btnadd.Name = "btnadd";
            this.btnadd.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnadd.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnadd.OnHoverForeColor = System.Drawing.Color.White;
            this.btnadd.OnHoverImage = null;
            this.btnadd.OnPressedColor = System.Drawing.Color.Black;
            this.btnadd.Radius = 8;
            this.btnadd.Size = new System.Drawing.Size(118, 42);
            this.btnadd.TabIndex = 11;
            this.btnadd.Text = "Add";
            this.btnadd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnsave
            // 
            this.btnsave.AnimationHoverSpeed = 0.07F;
            this.btnsave.AnimationSpeed = 0.03F;
            this.btnsave.BackColor = System.Drawing.Color.Transparent;
            this.btnsave.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.btnsave.BorderColor = System.Drawing.Color.Black;
            this.btnsave.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnsave.FocusedColor = System.Drawing.Color.Empty;
            this.btnsave.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.Color.White;
            this.btnsave.Image = null;
            this.btnsave.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.btnsave.ImageSize = new System.Drawing.Size(20, 20);
            this.btnsave.Location = new System.Drawing.Point(24, 331);
            this.btnsave.Name = "btnsave";
            this.btnsave.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btnsave.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnsave.OnHoverForeColor = System.Drawing.Color.White;
            this.btnsave.OnHoverImage = null;
            this.btnsave.OnPressedColor = System.Drawing.Color.Black;
            this.btnsave.Radius = 8;
            this.btnsave.Size = new System.Drawing.Size(118, 42);
            this.btnsave.TabIndex = 10;
            this.btnsave.Text = "Save";
            this.btnsave.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // txtguestaddress
            // 
            this.txtguestaddress.BaseColor = System.Drawing.Color.White;
            this.txtguestaddress.BorderColor = System.Drawing.Color.Silver;
            this.txtguestaddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtguestaddress.FocusedBaseColor = System.Drawing.Color.White;
            this.txtguestaddress.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtguestaddress.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtguestaddress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtguestaddress.Location = new System.Drawing.Point(182, 260);
            this.txtguestaddress.Name = "txtguestaddress";
            this.txtguestaddress.PasswordChar = '\0';
            this.txtguestaddress.SelectedText = "";
            this.txtguestaddress.Size = new System.Drawing.Size(212, 34);
            this.txtguestaddress.TabIndex = 9;
            // 
            // txtguestphone
            // 
            this.txtguestphone.BaseColor = System.Drawing.Color.White;
            this.txtguestphone.BorderColor = System.Drawing.Color.Silver;
            this.txtguestphone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtguestphone.FocusedBaseColor = System.Drawing.Color.White;
            this.txtguestphone.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtguestphone.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtguestphone.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtguestphone.Location = new System.Drawing.Point(182, 206);
            this.txtguestphone.Name = "txtguestphone";
            this.txtguestphone.PasswordChar = '\0';
            this.txtguestphone.SelectedText = "";
            this.txtguestphone.Size = new System.Drawing.Size(212, 34);
            this.txtguestphone.TabIndex = 8;
            // 
            // txtguestage
            // 
            this.txtguestage.BaseColor = System.Drawing.Color.White;
            this.txtguestage.BorderColor = System.Drawing.Color.Silver;
            this.txtguestage.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtguestage.FocusedBaseColor = System.Drawing.Color.White;
            this.txtguestage.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtguestage.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtguestage.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtguestage.Location = new System.Drawing.Point(182, 151);
            this.txtguestage.Name = "txtguestage";
            this.txtguestage.PasswordChar = '\0';
            this.txtguestage.SelectedText = "";
            this.txtguestage.Size = new System.Drawing.Size(212, 34);
            this.txtguestage.TabIndex = 7;
            // 
            // txtguestname
            // 
            this.txtguestname.BaseColor = System.Drawing.Color.White;
            this.txtguestname.BorderColor = System.Drawing.Color.Silver;
            this.txtguestname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtguestname.FocusedBaseColor = System.Drawing.Color.White;
            this.txtguestname.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtguestname.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtguestname.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtguestname.Location = new System.Drawing.Point(182, 95);
            this.txtguestname.Name = "txtguestname";
            this.txtguestname.PasswordChar = '\0';
            this.txtguestname.SelectedText = "";
            this.txtguestname.Size = new System.Drawing.Size(212, 36);
            this.txtguestname.TabIndex = 6;
            // 
            // txtguestid
            // 
            this.txtguestid.BaseColor = System.Drawing.Color.White;
            this.txtguestid.BorderColor = System.Drawing.Color.Silver;
            this.txtguestid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtguestid.FocusedBaseColor = System.Drawing.Color.White;
            this.txtguestid.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtguestid.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.txtguestid.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtguestid.Location = new System.Drawing.Point(182, 44);
            this.txtguestid.Name = "txtguestid";
            this.txtguestid.PasswordChar = '\0';
            this.txtguestid.SelectedText = "";
            this.txtguestid.Size = new System.Drawing.Size(212, 34);
            this.txtguestid.TabIndex = 5;
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel8.Location = new System.Drawing.Point(32, 260);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(80, 25);
            this.gunaLabel8.TabIndex = 4;
            this.gunaLabel8.Text = "Address";
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.Location = new System.Drawing.Point(32, 206);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(66, 25);
            this.gunaLabel7.TabIndex = 3;
            this.gunaLabel7.Text = "Phone";
            // 
            // guestrno
            // 
            this.guestrno.AutoSize = true;
            this.guestrno.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guestrno.Location = new System.Drawing.Point(32, 151);
            this.guestrno.Name = "guestrno";
            this.guestrno.Size = new System.Drawing.Size(46, 25);
            this.guestrno.TabIndex = 2;
            this.guestrno.Text = "Age";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.Location = new System.Drawing.Point(31, 95);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(62, 25);
            this.gunaLabel5.TabIndex = 1;
            this.gunaLabel5.Text = "Name";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(32, 44);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(29, 25);
            this.gunaLabel4.TabIndex = 0;
            this.gunaLabel4.Text = "Id";
            // 
            // gunaDataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.gunaDataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gunaDataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gunaDataGridView1.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.gunaDataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gunaDataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gunaDataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gunaDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gunaDataGridView1.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gunaDataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.gunaDataGridView1.EnableHeadersVisualStyles = false;
            this.gunaDataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.Location = new System.Drawing.Point(575, 75);
            this.gunaDataGridView1.Name = "gunaDataGridView1";
            this.gunaDataGridView1.RowHeadersVisible = false;
            this.gunaDataGridView1.RowHeadersWidth = 62;
            this.gunaDataGridView1.RowTemplate.Height = 28;
            this.gunaDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gunaDataGridView1.Size = new System.Drawing.Size(596, 479);
            this.gunaDataGridView1.TabIndex = 5;
            this.gunaDataGridView1.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.gunaDataGridView1.ThemeStyle.BackColor = System.Drawing.Color.Gainsboro;
            this.gunaDataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            this.gunaDataGridView1.ThemeStyle.ReadOnly = false;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.gunaDataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.gunaDataGridView1.ThemeStyle.RowsStyle.Height = 28;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // Guest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1168, 555);
            this.Controls.Add(this.gunaDataGridView1);
            this.Controls.Add(this.gunaGroupBox1);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Guest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guest";
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel1.PerformLayout();
            this.gunaGroupBox1.ResumeLayout(false);
            this.gunaGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaDataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaImageButton btnexit;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaGroupBox gunaGroupBox1;
        private Guna.UI.WinForms.GunaButton btndisplay;
        private Guna.UI.WinForms.GunaButton btnupdate;
        private Guna.UI.WinForms.GunaButton btnadd;
        private Guna.UI.WinForms.GunaButton btnsave;
        private Guna.UI.WinForms.GunaTextBox txtguestaddress;
        private Guna.UI.WinForms.GunaTextBox txtguestphone;
        private Guna.UI.WinForms.GunaTextBox txtguestage;
        private Guna.UI.WinForms.GunaTextBox txtguestname;
        private Guna.UI.WinForms.GunaTextBox txtguestid;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaLabel guestrno;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaDataGridView gunaDataGridView1;
    }
}